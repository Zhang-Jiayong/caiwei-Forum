function INTG = Gijkl_on_ellipse_aniso(ellipse,C_tensor,theta, phi)
% test code to see if we can prove Tr(SE) = 3 by examining the integrand
%  (inv(zz))_ij z_k z_l sin(phi) beta^(-3)

if (~exist('ellipse'))
    ellipse = [5 4 7];
end

integrand = zeros(3,3,3,3);

% integrand is (inv(zz))_ij z_k z_l sin(phi) beta^(-3)
z = [cos(theta)*sin(phi), sin(theta)*sin(phi), cos(phi)];
zz = zeros(3,3);
for i=1:3, for j=1:3, for k=1:3, for l=1:3,
                zz(j,k) = zz(j,k) + z(i)*C_tensor(i,j,k,l)*z(l);
end; end; end; end
invzz = inv(zz);

% area of surface patch dA_k = n_k * dS
a = ellipse(1); b = ellipse(2); c = ellipse(3);
beta = sqrt( (a^2*cos(theta)^2 + b^2*sin(theta)^2)*sin(phi)^2 + c^2*cos(phi)^2 );

%integrand = - (a*b*c)/(4*pi) * integrand;

for i=1:3, for j=1:3, for k=1:3, for l=1:3,
                integrand(i,j,k,l) = invzz(i,j)*z(k)*z(l); %*sin(phi)/beta^3;
end; end; end; end

voigt_ind = [ 1 6 5
              6 2 4
              5 4 3 ];

INTG = zeros(6,6);
for i=1:3, for j=1:3, for k=1:3, for l=1:3,
       I = voigt_ind(i,j);
       J = voigt_ind(k,l);
       INTG(I,J) = integrand(i,j,k,l)*(1+(I>=4));
end; end; end; end

