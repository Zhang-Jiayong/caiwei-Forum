function C_tensor = triclinic_elast_tensor(tau)
% construct triclinic elastic constants
% positive definite iff |tau| < (3/8)*sqrt(15)

if abs(tau) >= (3/8)*sqrt(15)
    disp('tau >= (3/8)*sqrt(15), matrix not positive definite');
end

S_voigt = [4         1     2    1/3   2/3  (1+tau)/3 
           1         5/4   3/2  1/3   1/2  5/16
           2         3/2   3    2/3   1    1/2
           1/3       1/3   2/3  2/9   2/9  1/9
           2/3       1/2   1    2/9   3    1/4
           (1+tau)/3 5/16  1/2  1/9   1/4  3/16 ];
       
C_voigt = inv(S_voigt);

voigt_ind = [ 1 6 5
              6 2 4
              5 4 3 ];

C_tensor = zeros(3,3,3,3);
for i=1:3, for j=1:3, for k=1:3, for l=1:3,
       I = voigt_ind(i,j);
       J = voigt_ind(k,l);
       C_tensor(i,j,k,l) = C_voigt(I,J);
end; end; end; end

