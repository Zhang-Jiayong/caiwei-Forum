function [C_tensor C_voigt] = arbitrary_elast_tensor()
% construct arbitrary (positive definite) elastic constants

tmp = rand(6,6);  tmp = tmp + tmp'; % create symmetric matrix
[V, D] = eig(tmp);  % tmp == V*D*V'
C_voigt = V*abs(D)*V';

voigt_ind = [ 1 6 5
              6 2 4
              5 4 3 ];

C_tensor = zeros(3,3,3,3);
for i=1:3, for j=1:3, for k=1:3, for l=1:3,
       I = voigt_ind(i,j);
       J = voigt_ind(k,l);
       C_tensor(i,j,k,l) = C_voigt(I,J);
end; end; end; end

