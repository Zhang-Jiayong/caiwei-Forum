% test eigenvalues for Eshelby tensor (anisotropic elasticity) - triclinic


N_test = 5;
tol = 1e-5; 

if (1)
    load eig_SE_triclinic_data
else
    tauabc = zeros(N_test,4);
    eigvals = zeros(N_test,6);
    tic
    for iter = 1:N_test,
        % stability condition: abs(tau) < (3/8)*sqrt(15)
        tau = (2*rand()-1)*(3/8)*sqrt(15);
        C0_tensor = triclinic_elast_tensor(tau);
        
        % ellipsoidal inclusion
        a = rand(); b = rand(); c = rand();
        tauabc(iter,:) = [tau, a, b, c];
        
        [Q,R] = qr(randn(3));
        %C_tensor = C0_tensor;
        C_tensor=rotate_tensor_4th(C0_tensor,Q);

        SE_aniso_num = eshelby_tensor_aniso(C_tensor, a, b, c, tol);
        eig_aniso_num = eig(SE_aniso_num);

        eigvals(iter,:) = sort(eig_aniso_num);
        disp(sprintf('iter = %d/%d, tau = %g, min eig = %g, max eig = %g', iter, N_test, tau, min(eig_aniso_num), max(eig_aniso_num)));        
    end
    toc
end

fs = 14;
figure(1);
plot(tauabc(:,1),eigvals(:,6),'r.', [-1.45 1.45], [0.5 0.5], 'b--', tauabc(:,1),eigvals(:,1),'b.');
%plot(tauabc(:,1),eigvals(:,5),'r.', [-1.45 1.45], [0.5 0.5], 'b--', tauabc(:,1),eigvals(:,2),'b.');
%plot(tauabc(:,1),eigvals(:,4),'r.', [-1.45 1.45], [0.5 0.5], 'b--', tauabc(:,1),eigvals(:,3),'b.');
title('Eigenvalues of Eshelby Tensor (anisotropic elasticity) triclinic');
set(gca,'FontSize',fs);
xlabel('\tau');
%legend('\lambda_6 (largest)','0.5','\lambda_1 (smallest)','Location','west');

% examine what is the meaning of eigenvectors/eigenvalues of SE
ind = 3;
[V,D]=eig(SE_aniso_num);
voigt_ind = [ 1 6 5
              6 2 4
              5 4 3 ];
e_tensor = zeros(3,3);
for i=1:3, for j=1:3,
       I = voigt_ind(i,j);
       e_tensor(i,j) = V(I,ind)/(1+(I>=4));
end; end; 
disp(sprintf('eigen strain corresponding to the %d eigenvector of SE',ind));
disp(e_tensor);