function [int_G] = int_Gijkl_on_ellipse_iso(ellipse,x,myMU,NU,tol)
% compute the auxiliary tensor D_ijkl needed to form Eshelby tensor S_ijkl
% integral is performed on the surface of ellipse in real-space
% applicable only to isotropic elastic medium 
% but field point can be inside or outside the inclusion

if (~exist('ellipse'))
    ellipse = [5 4 7];
end

if (~exist('x'))
    x = [0 0 0];
end

if (~exist('myMU'))
    myMU = 1.0;
end

if (~exist('NU'))
    NU = 0.3;
end

if (~exist('tol'))
    tol = 1e-6;
end

int_theta_phi = quadv(@integrand_phi,0,pi,tol);

int_G = zeros(3,3,3,3);
n=1;
for i=1:3, for j=1:3, for k=1:3, for l=1:3,
    int_G(i,j,k,l) = int_theta_phi(n);
    n = n+1;
end; end; end; end

int_G = int_G / (16*pi*myMU*(1-NU));

    function int_theta = integrand_phi(phi)        
        int_theta = quadv(@integrand_theta,0,2*pi,tol);
        
        function data = integrand_theta(theta)                
            % integrand is G_ij,l * n_k
            
            % area of surface patch dA_k = n_k * dS
            a = ellipse(1); b = ellipse(2); c = ellipse(3);
            dA = [b*c*cos(theta)*sin(phi)^2
                  a*c*sin(theta)*sin(phi)^2
                  a*b*sin(phi)*cos(phi) ];
            
            % G_ij = ( (3-4*nu) delta_ij/r + dx_i*dx_j/r^3 ) / (16*pi*mu*(1-nu)
            % G_ij,l = ( -(3-4*nu) delta_ij dx_l/r^3
            %            + delta_il*dx_j/r^3 + delta_jl*dx_i/r^3
            %            - 3 dx_i*dx_j*dx_l/r^5 ) / (16*pi*mu*(1-nu)            
            G_ijl = zeros(3,3,3);
            xp = [a*cos(theta)*sin(phi),b*sin(theta)*sin(phi),c*cos(phi)];
            dx = x - xp;
            r = norm(dx);
            for i=1:3, for j=1:3, for l=1:3,
                G_ijl(i,j,l) =  -(3-4*NU)*(i==j)*dx(l)/r^3 ...
                                +(i==l)*dx(j)/r^3 + (j==l)*dx(i)/r^3 ...
                                -3*dx(i)*dx(j)*dx(l)/r^5;
            end; end; end
            
            data=zeros(3^4,1); n=1;
            for i=1:3, for j=1:3, for k=1:3, for l=1:3,
                data(n) = -G_ijl(i,j,l)*dA(k);
                n = n+1;
            end; end; end; end
        end        
    end
end