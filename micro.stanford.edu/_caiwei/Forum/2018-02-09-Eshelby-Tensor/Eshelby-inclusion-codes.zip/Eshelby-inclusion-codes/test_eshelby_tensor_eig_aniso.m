% test eigenvalues for Eshelby tensor (anisotropic elasticity) - arbitrary positive definite elastic stiffness tensor


N_test = 1; %500;
tol = 1e-5; 

if (0)
    load eig_SE_aniso_data
else
    tauabc = zeros(N_test,4);
    eigvals = zeros(N_test,6);
    tic
    for iter = 1:N_test,
        [C_tensor C_voigt]=arbitrary_elast_tensor();
        tau = C_tensor(1,1,1,1)/C_tensor(1,2,1,2);
        
        % ellipsoidal inclusion
        a = rand(); b = rand(); c = rand();
        tauabc(iter,:) = [tau, a, b, c];
        
        [SE_aniso_num P_aniso_num] = eshelby_tensor_aniso(C_tensor, a, b, c, tol);
        eig_aniso_num = eig(SE_aniso_num);

        eigvals(iter,:) = sort(eig_aniso_num);
        disp(sprintf('iter = %d/%d, tau = %g, min eig = %g, max eig = %g', iter, N_test, tau, min(eig_aniso_num), max(eig_aniso_num)));        
    end
    toc
end

fs = 21;
figure(1);
p1=plot(tauabc(:,1),eigvals(:,6),'ro', [0 4.5], [0.5 0.5], 'b--', tauabc(:,1),eigvals(:,1),'b.');
set(p1(1),'MarkerSize',4,'MarkerFaceColor',[1 1 1]);
%plot(tauabc(:,1),eigvals(:,5),'r.', [0 4.5], [0.5 0.5], 'b--', tauabc(:,1),eigvals(:,2),'b.');
%plot(tauabc(:,1),eigvals(:,4),'r.', [0 4.5], [0.5 0.5], 'b--', tauabc(:,1),eigvals(:,3),'b.');
%title('Eigenvalues of Eshelby Tensor arbitrary (PD) C tensor');
set(gca,'FontSize',fs);
xlabel('C_{1111} / C_{1212}','FontName','Times');
xlim([0 3])
ylabel('\lambda')
%legend('\lambda_6 (largest)','0.5','\lambda_1 (smallest)','Location','west');

% examine what is the meaning of eigenvectors/eigenvalues of SE
ind = 3;
[V,D]=eig(SE_aniso_num);
voigt_ind = [ 1 6 5
              6 2 4
              5 4 3 ];
e_tensor = zeros(3,3);
for i=1:3, for j=1:3,
       I = voigt_ind(i,j);
       e_tensor(i,j) = V(I,ind)/(1+(I>=4));
end; end; 
disp(sprintf('eigen strain corresponding to the %d eigenvector of SE',ind));
disp(e_tensor);