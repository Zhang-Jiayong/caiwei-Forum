% test cases for Eshelby tensor computation

% Compute Eshelby tensor

% isotropic elasticity
nu = 0.3;  MU = 1.0; lambda = 2*MU*nu/(1-2*nu);
C11 = lambda+2*MU; C12 = lambda; C44 = MU; C_tensor=cubic_elast_stiff(C11,C12,C44);

% ellipsoidal inclusion
a = 2; b = 1.5; c = 1;

% analytic expression - isotropic elasticity
SE_iso_anl = eshelby_tensor_iso(nu, a, b, c);
eig_iso_anl = eig(SE_iso_anl);

disp(SE_iso_anl);
disp(eig_iso_anl);

% numerical integration - isotropic elasticity
tol = 1e-8;
D_tensor_iso = int_Gijkl_on_ellipse_iso([a b c],[0 0 0],1,nu,tol);
SE_tensor_iso = zeros(size(C_tensor));
for i=1:3, for j=1:3, for m=1:3, for n=1:3, for k=1:3, for l=1:3,
    SE_tensor_iso(i,j,m,n) = SE_tensor_iso(i,j,m,n)-0.5*C_tensor(l,k,m,n)*(D_tensor_iso(i,k,l,j)+D_tensor_iso(j,k,l,i));
end; end; end; end; end; end;

voigt_ind = [ 1 6 5
              6 2 4
              5 4 3 ];
          
SE_iso_num = zeros(6,6);
for i=1:3, for j=1:3, for k=1:3, for l=1:3,
       I = voigt_ind(i,j);
       J = voigt_ind(k,l);
       SE_iso_num(I,J) = SE_tensor_iso(i,j,k,l)*(1+(I>=4));
end; end; end; end
eig_iso_num = eig(SE_iso_num);

disp(SE_iso_num);
disp(eig_iso_num);

disp('Maximum difference between SE_iso_anl and SE_iso_num = ');
disp(max(max(abs(SE_iso_anl - SE_iso_num))))

% numerical integration - anisotropic elasticity
D_tensor_aniso = int_Gijkl_on_ellipse_aniso([a b c],C_tensor,tol);
SE_tensor_aniso = zeros(size(C_tensor));
for i=1:3, for j=1:3, for m=1:3, for n=1:3, for k=1:3, for l=1:3,
    SE_tensor_aniso(i,j,m,n) = SE_tensor_aniso(i,j,m,n)-0.5*C_tensor(l,k,m,n)*(D_tensor_aniso(i,k,l,j)+D_tensor_aniso(j,k,l,i));
end; end; end; end; end; end;

SE_aniso_num = zeros(6,6);
for i=1:3, for j=1:3, for k=1:3, for l=1:3,
       I = voigt_ind(i,j);
       J = voigt_ind(k,l);
       SE_aniso_num(I,J) = SE_tensor_aniso(i,j,k,l)*(1+(I>=4));
end; end; end; end
eig_aniso_num = eig(SE_aniso_num);

disp(SE_aniso_num);
disp(eig_aniso_num);

disp('Maximum difference between SE_iso_anl and SE_aniso_num = ');
disp(max(max(abs(SE_iso_anl - SE_aniso_num))))
