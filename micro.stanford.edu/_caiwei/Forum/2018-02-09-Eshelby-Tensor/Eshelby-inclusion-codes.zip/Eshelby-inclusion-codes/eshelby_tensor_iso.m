function SE = eshelby_tensor_iso (nu, a, b, c)
% compute Eshelby tensor in isotropic elasticity
% nu: Poisson's ratio
% a, b, c: semi-axes of ellipsoid
%
% to do: the general ellipsoid case did not match (for S1122, S1133)
%        find the typo on lecture notes
%        compare ME340B notes with Mura's book

SE4 = zeros(3,3,3,3);

if (a==b) && (b==c)
    term1 = (5*nu-1)/(15*(1-nu));
    term2 = (4-5*nu)/(15*(1-nu));
    for i=1:3, for j=1:3, for k=1:3, for l=1:3,
       SE4(i,j,k,l) = term1*(i==j)*(k==l) + term2*((i==k)*(j==l)+(i==l)*(j==k));
    end; end; end; end
else
    [S1111,S1122,S1133,S1212] = eshelby_tensor_components(a,b,c,nu);
    SE4(1,1,1,1) = S1111; SE4(1,1,2,2) = S1122; SE4(1,1,3,3) = S1133;
    SE4(1,2,1,2) = S1212; SE4(1,2,2,1) = S1212; SE4(2,1,2,1) = S1212; SE4(2,1,1,2) = S1212;
    
    [S2222,S2233,S2211,S2323] = eshelby_tensor_components(b,c,a,nu);
    SE4(2,2,2,2) = S2222; SE4(2,2,3,3) = S2233; SE4(2,2,1,1) = S2211;
    SE4(2,3,2,3) = S2323; SE4(2,3,3,2) = S2323; SE4(3,2,3,2) = S2323; SE4(3,2,2,3) = S2323;

    [S3333,S3311,S3322,S3131] = eshelby_tensor_components(c,a,b,nu);
    SE4(3,3,3,3) = S3333; SE4(3,3,1,1) = S3311; SE4(3,3,2,2) = S3322;
    SE4(3,1,3,1) = S3131; SE4(3,1,1,3) = S3131; SE4(1,3,1,3) = S3131; SE4(1,3,3,1) = S3131;
end

voigt_ind = [ 1 6 5
              6 2 4
              5 4 3 ];
          
SE = zeros(6,6);
for i=1:3, for j=1:3, for k=1:3, for l=1:3,
       I = voigt_ind(i,j);
       J = voigt_ind(k,l);
       SE(I,J) = SE4(i,j,k,l)*(1+(I>=4));
end; end; end; end


    function [S1111, S1122, S1133, S1212] = eshelby_tensor_components(a,b,c,nu)
        theta = asin(sqrt((a^2-c^2)/(a^2)));
        m = (a^2-b^2)/(a^2-c^2);
        Ftk = ellipticF(theta, m);
        Etk = ellipticE(theta, m);
        I1 = 4*pi*a*b*c/(a^2-b^2)/sqrt(a^2-c^2)*(Ftk-Etk);
        I3 = 4*pi*a*b*c/(b^2-c^2)/sqrt(a^2-c^2)*(b*sqrt(a^2-c^2)/(a*c)-Etk);
        I2 = 4*pi - I1 - I3;
        I12 = (I2 - I1)/(a^2-b^2);
        MAT = [3 1 1; 3*a^2 b^2 c^2; 0 1 0];
        RHS = [4*pi/(a^2); 3*I1; I12];
        x = MAT \ RHS;
        I11 = x(1); I13 = x(3);
        %disp([I11 I12 I13]);
        fac = 1/(8*pi*(1-nu));
        S1111 = fac * (3*a^2*I11 + (1-2*nu)*I1);
        S1122 = fac * (1*b^2*I12 - (1-2*nu)*I1);
        S1133 = fac * (1*c^2*I13 - (1-2*nu)*I1);
        S1212 = fac * (0.5*(a^2+b^2)*I12 + 0.5*(1-2*nu)*(I1+I2));
    end

end
