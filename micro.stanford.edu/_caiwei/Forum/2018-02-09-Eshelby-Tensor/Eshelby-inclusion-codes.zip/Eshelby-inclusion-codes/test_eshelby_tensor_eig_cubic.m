% test eigenvalues for Eshelby tensor (anisotropic elasticity) - cubic


N_test = 500;
tol = 1e-5; 

if (1)
    load eig_SE_cubic_data_2
else
    C11C12C44abc = zeros(N_test,6);
    eigvals = zeros(N_test,6);
    tic
    for iter = 1:N_test,
        % stability condition: C11 - C12 > 0 ; C11 + 2C12 > 0 ; C44 > 0
        C11_minus_C12 = rand();  C11_plus_2C12 = rand(); C44 = rand();
        C11 = (2*C11_minus_C12 + C11_plus_2C12) / 3;
        C12 = (C11_plus_2C12 - C11_minus_C12) / 3;
        
        % ellipsoidal inclusion
        a = rand(); b = rand(); c = rand();
        C11C12C44abc(iter,:) = [C11, C12, C44, a, b, c];
        
        [Q,R] = qr(randn(3));
        C0_tensor=cubic_elast_stiff(C11,C12,C44);
        %C_tensor = C0_tensor;
        C_tensor=rotate_tensor_4th(C0_tensor,Q);

        SE_aniso_num = eshelby_tensor_aniso(C_tensor, a, b, c, tol);
        eig_aniso_num = eig(SE_aniso_num);

        eigvals(iter,:) = sort(eig_aniso_num);
        disp(sprintf('iter = %d/%d, C11 = %g, C12 = %g, C44 = %g, min eig = %g, max eig = %g', iter, N_test, C11, C12, C44, min(eig_aniso_num), max(eig_aniso_num)));        
    end
    toc
end

fs = 21;
figure(1);
C44_over_C11 = C11C12C44abc(:,3)./C11C12C44abc(:,1);
p1=semilogx(C44_over_C11,eigvals(:,6),'ro', [min(C44_over_C11) max(C44_over_C11)], [0.5 0.5], 'b--', C44_over_C11,eigvals(:,1),'b.');
set(p1(1),'MarkerSize',4,'MarkerFaceColor',[1 1 1]);
%semilogx(C44_over_C11,eigvals(:,5),'r.', [min(C44_over_C11) max(C44_over_C11)], [0.5 0.5], 'b--', C44_over_C11,eigvals(:,2),'b.');
%semilogx(C44_over_C11,eigvals(:,4),'r.', [min(C44_over_C11) max(C44_over_C11)], [0.5 0.5], 'b--', C44_over_C11,eigvals(:,3),'b.');
%title('Eigenvalues of Eshelby Tensor (anisotropic elasticity)');
set(gca,'FontSize',fs);
ylabel('\lambda')
xlabel('C_{44} / C_{11}','FontName','Times');
xlim([1e-2 1e1]);
%legend('\lambda_6 (largest)','0.5','\lambda_1 (smallest)','Location','west');

% examine what is the meaning of eigenvectors/eigenvalues of SE
ind = 3;
[V,D]=eig(SE_aniso_num);
voigt_ind = [ 1 6 5
              6 2 4
              5 4 3 ];
e_tensor = zeros(3,3);
for i=1:3, for j=1:3,
       I = voigt_ind(i,j);
       e_tensor(i,j) = V(I,ind)/(1+(I>=4));
end; end; 
disp(sprintf('eigen strain corresponding to the %d eigenvector of SE',ind));
disp(e_tensor);