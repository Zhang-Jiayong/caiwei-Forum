% test eigenvalues for Eshelby tensor (isotropic elasticity)

N_test = 100;

if (1)
    load eig_SE_iso_data
else
    nuabc = zeros(N_test,4);
    eigvals = zeros(N_test,6);
    for iter = 1:N_test,
        nu = rand()*1.5 - 1; % random number from -1 to 0.5
        %nu = rand()*0.5; % randum number from 0 to 0.5

        % ellipsoidal inclusion
        a = rand(); b = rand(); c = rand();

        nuabc(iter,:) = [nu, a, b, c];
        SE_iso_anl = eshelby_tensor_iso(nu, a, b, c);
        eig_iso_anl = eig(SE_iso_anl);
        
        eigvals(iter,:) = sort(eig_iso_anl);
        
        %eig_iso_anl = eig(SE_iso_anl + SE_iso_anl'); % this is to check positive definiteness
        %disp(sprintf('iter = %d/%d, min eig = %g', iter, N_test, min(eig_iso_anl)));
        %if min(eig_iso_anl) < 0  % find example of non-positive definiteness
        %    break;
        %end
    end
end

fs = 21;
figure(1);
clf
%subplot(2,1,1);
%plot(nuabc(:,1),eigvals(:,6),'.')
p1=plot(nuabc(:,1),eigvals(:,6),'ro',[-1 0.5], [0.5 0.5], 'b--', nuabc(:,1),eigvals(:,1),'b.');
set(p1(1),'MarkerSize',4,'MarkerFaceColor',[1 1 1]);
%title('Eigenvalues of Eshelby Tensor (isotropic elasticity)');
set(gca,'FontSize',fs);
xlabel('\nu');
ylabel('\lambda');
%ylabel('\lambda_6 (largest)');
%subplot(2,1,2);
%plot(nuabc(:,1),eigvals(:,1),'.')
%set(gca,'FontSize',fs);
%ylabel('\lambda_1 (smallest)');
%legend('\lambda_6 (largest)','0.5','\lambda_1 (smallest)','Location','west');

% examine what is the meaning of eigenvectors/eigenvalues of SE
ind = 4;
[V,D]=eig(SE_iso_anl);
voigt_ind = [ 1 6 5
              6 2 4
              5 4 3 ];
e_tensor = zeros(3,3);
for i=1:3, for j=1:3,
       I = voigt_ind(i,j);
       e_tensor(i,j) = V(I,ind)/(1+(I>=4));
end; end; 
disp(sprintf('eigen strain corresponding to the %d eigenvector of SE',ind));
disp(e_tensor);